MIXDOWN
=======

I use SoundCloud to find DJ mixes to listen to in the car. I have some pretty niche requirements though. The mixes need to be at least 30 minutes long, it needs to be downloadable and it needs to be good.

Therefore, this tool will filter out stuff that doesn't suit me, and with a bit of luck, also allow sorting by plays / favs / downloads etc.  This should, in theory, allow me to find the better mixes quicker.